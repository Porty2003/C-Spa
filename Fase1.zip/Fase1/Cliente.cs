﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1
{
    internal class Cliente
    {
        public string Cedula { get; set; }
        public string Nombre { get; set; }
        public int Estrato { get; set; }

        public Cliente(string cedula, string nombre, int estrato)
        {
            Cedula = cedula;
            Nombre = nombre;
            Estrato = estrato;
        }
    }
}
