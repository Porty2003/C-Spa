﻿using Fase1;
using System;

class Program
{
    static void Main(string[] args)
    {
        Console.ForegroundColor = ConsoleColor.Cyan;

        // Mostrar  bienvenida
        Console.WriteLine("*****************************************");
        Console.WriteLine("*          Simulador SPA ROBLES         *");
        Console.WriteLine("*****************************************");

        // Información inicial
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("\nBienvenido, Daniel David Del Portillo Acosta");
        Console.WriteLine("Curso: Estructura de Datos\n");

        Console.ForegroundColor = ConsoleColor.Cyan;

        // Verificar la contraseña de acceso
        string password = "123";
        Console.WriteLine("-------------------------------------------");
        Console.Write("Ingrese su contraseña: ");
        string passwordIngresado = Console.ReadLine();
        while (passwordIngresado != password)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Contraseña incorrecta. Intente de nuevo.");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Ingrese su contraseña: ");
            passwordIngresado = Console.ReadLine();
        }

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("\nAcceso concedido. Ingresando al sistema...\n");

        // Solicitar información del usuario
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("-------------------------------------------");
        Console.Write("Ingrese su cédula: ");
        string cedula = Console.ReadLine();

        Console.Write("Ingrese su nombre completo: ");
        string nombre = Console.ReadLine();

        Console.Write("Ingrese el estrato al que pertenece: ");
        int estrato = int.Parse(Console.ReadLine());

        Console.WriteLine("\nSeleccione el tipo de servicio:");
        Console.WriteLine("1. Corte y cepillado - $60,000");
        Console.WriteLine("2. Corte, cepillado y uñas - $90,000");
        Console.WriteLine("3. Uñas en acrílico y cejas - $100,000");
        Console.WriteLine("4. Uñas en acrílico, maquillaje y cejas - $140,000");
        Console.Write("Ingrese el número del servicio que desea: ");
        int tipoServicio = int.Parse(Console.ReadLine());

        // Crear objetos de Cliente y ServicioSpa
        Cliente cliente = new Cliente(cedula, nombre, estrato);
        ServicioSpa servicio = new ServicioSpa(tipoServicio);

        // Calcular el precio final
        SimuladorSpa simulador = new SimuladorSpa();
        decimal descuento = simulador.CalcularDescuento(cliente.Estrato, servicio.Precio);
        decimal precioFinal = simulador.CalcularPrecioFinal(servicio.Precio, descuento);

        // Mostrar resultado
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("\n---Detalles del Servicio---");
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"Cédula del cliente: {cliente.Cedula}");
        Console.WriteLine($"Nombre del cliente: {cliente.Nombre}");
        Console.WriteLine($"Estrato socioeconómico: {cliente.Estrato}");
        Console.WriteLine($"Servicio utilizado: {servicio.NombreServicio}");
        Console.WriteLine($"Precio del servicio: ${servicio.Precio}");
        Console.WriteLine($"Descuento aplicado: ${descuento}");
        Console.WriteLine($"Valor final a pagar: ${precioFinal}");
        Console.ResetColor();
    }
}