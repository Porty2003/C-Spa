﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1
{
    internal class ServicioSpa
    {
        public string NombreServicio { get; set; }
        public decimal Precio { get; set; }

        private static readonly Dictionary<int, string> serviciosDisponibles = new Dictionary<int, string>
        {
            {1, "Corte y cepillado"},
            {2, "Corte, cepillado y uñas"},
            {3, "Uñas en acrílico y cejas"},
            {4, "Uñas en acrílico, maquillaje y cejas"}
        };

        private static readonly Dictionary<int, decimal> preciosServicios = new Dictionary<int, decimal>
        {
            {1, 60000m},
            {2, 90000m},
            {3, 100000m},
            {4, 140000m}
        };

        public ServicioSpa(int tipoServicio)
        {
            NombreServicio = serviciosDisponibles[tipoServicio];
            Precio = preciosServicios[tipoServicio];
        }
    }
}
