﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1
{
    internal class SimuladorSpa
    {
        public decimal CalcularDescuento(int estrato, decimal precio)
        {
            decimal descuento = 0m;

            if (estrato == 1 || estrato == 2)
                descuento = precio * 0.15m;
            else if (estrato == 3 || estrato == 4)
                descuento = precio * 0.10m;
            else if (estrato >= 5)
                descuento = precio * 0.05m;

            return descuento;
        }

        public decimal CalcularPrecioFinal(decimal precio, decimal descuento)
        {
            return precio - descuento;
        }
    }
}

